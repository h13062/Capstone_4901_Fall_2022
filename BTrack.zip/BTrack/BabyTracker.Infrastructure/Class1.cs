﻿namespace BabyTracker.Infrastructure
{
    public class Class1
    {

    }
}